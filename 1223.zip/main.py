class Persona:
    def __init__(self, nombre, apellido, edad):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
    
    def saludar(self):
        print(f"Hola, soy {self.nombre}")
    
    def comer(self):
        print(f"{self.nombre} está comiendo")
    
    def mostrarInfo(self):
        print(f"Nombre: {self.nombre} {self.apellido}, Edad: {self.edad}")
        
profesor = Persona("Juan", "Pérez", 45)
alumno = Persona("María", "García", 20)
vendedor = Persona("Carlos", "López", 35)

print("PROFESOR")
profesor.mostrarInfo()
profesor.saludar()
profesor.comer()

print("\n ALUMNO")
alumno.mostrarInfo()
alumno.saludar()

print("\n VENDEDOR")
vendedor.mostrarInfo()
vendedor.comer()