public class Main {
    
    static class Persona {
        String nombre;
        String apellido;
        int edad;
        
        public Persona(String nombre, String apellido, int edad) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
        }
        
        public void saludar() {
            System.out.println("Hola, soy " + nombre);
        }
        
        public void comer() {
            System.out.println(nombre + " está comiendo");
        }
        
        public void mostrarInfo() {
            System.out.println("Nombre: " + nombre + " " + apellido + ", Edad: " + edad);
        }
    }
    
    public static void main(String[] args) {
        Persona profesor = new Persona("Juan", "Pérez", 45);
        Persona alumno = new Persona("María", "García", 20);
        Persona vendedor = new Persona("Carlos", "López", 35);
        
        System.out.println(" PROFESOR ");
        profesor.mostrarInfo();
        profesor.saludar();
        
        System.out.println("\n ALUMNO ");
        alumno.mostrarInfo();
        alumno.comer();
        
        System.out.println("\n VENDEDOR ");
        vendedor.mostrarInfo();
        vendedor.saludar();
    }
}