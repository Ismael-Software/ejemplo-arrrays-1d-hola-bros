numeros=[]
for i in range(5):
    numeros.append(str(input("ingresa un numero: ")))
print("suma: ",sum(numeros))
print("numero mayor: ",max(numeros))